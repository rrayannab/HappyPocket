'use strict';


module.exports = {
    items: [
        { item_name: 'Item 1', amount: 1.00, currency_code: 'USD' },
        { item_name: 'Item 2', amount: 2.34, custom: 'foo' }
    ]
};
